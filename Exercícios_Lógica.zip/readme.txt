	1- Calculadora:
1- Solicita dois números ao usuário e os converte para valores numéricos.
2- Realiza as operações de soma, subtração, multiplicação e divisão entre os números informados.
3- Exibe os resultados das operações na tela.

	2- Média Aritmética:
1- Solicita três notas ao usuário e as converte para valores numéricos.
2- Calcula a soma das três notas.
3- Calcula a média dividindo a soma por três.
4- Exibe a média na tela.
	
	3- Conversão de Temperatura:
1- Solicita ao usuário a temperatura em graus Celsius.
2- Converte a temperatura para Fahrenheit usando a fórmula 
(°𝐶x9/5)+32
3- Exibe o resultado na tela.

	4- Área do Retângulo:
1- Solicita ao usuário a base e a altura de um retângulo.
2- Calcula a área multiplicando base por altura.
3- Exibe o resultado na tela.

	5- Antecessor e Sucessor:
1- Solicita um número ao usuário.
2- Calcula o sucessor somando 1.
3- Calcula o antecessor subtraindo 1.
4- Exibe os dois resultados na tela.

	6- Dobro e Metade:
1- Solicita um número ao usuário.
2- Calcula o dobro do número multiplicando por 2.
3- Calcula a metade do número dividindo por 2.
4- Exibe os dois resultados na tela.

	7- Cálculo de Salário:
1- Solicita a quantidade de horas trabalhadas no dia.
2- Solicita o valor da hora trabalhada.
3- Calcula o salário diário multiplicando as horas pelo valor da hora.
4- Calcula o salário mensal multiplicando o salário diário por 20.
5- Exibe o salário diário e o salário mensal na tela.

	8- Conversão de Moeda:
1- Solicita a quantidade de horas trabalhadas no dia.
2- Solicita o valor da hora trabalhada.
3- Calcula o salário diário multiplicando as horas pelo valor da hora.
4- Calcula o salário mensal multiplicando o salário diário por 20 (considerando 20 dias úteis no mês).
5- Exibe o salário diário e o salário mensal na tela.
 
	9- Salário mensal:
1- Solicita o salário atual do usuário.
2- Solicita o percentual de aumento.
3- Calcula o valor do aumento salarial.
4- Calcula o novo salário somando o aumento ao salário atual.
5- Exibe o novo salário na tela.

	10- Velocidade Média:
1- Solicita a distância percorrida em km.
2- Solicita o tempo em horas para completar o percurso.
3- Calcula a velocidade média dividindo a distância pelo tempo.
4- Exibe a velocidade média em km/h.






